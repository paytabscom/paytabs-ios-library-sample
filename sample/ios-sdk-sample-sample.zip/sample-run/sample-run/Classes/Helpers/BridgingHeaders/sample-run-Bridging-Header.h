//
//  sample-run-Bridging-Header.h
//  sample-run
//
//  Created by PayTabs LLC on 10/5/17.
//  Copyright © 2017 PayTabs LLC. All rights reserved.
//

#ifndef sample_run_Bridging_Header_h
#define sample_run_Bridging_Header_h

#import <paytabs-iOS/paytabs_iOS.h>


#endif /* sample_run_Bridging_Header_h */
