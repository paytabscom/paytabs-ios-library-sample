//
//  ViewController.m
//  CarsirentNew
//
//  Created by Bugdev Studio on 07/06/2018.
//  Copyright © 2018 bugdev. All rights reserved.
//

#import "ViewController.h"
#import <paytabs-iOS/paytabs_iOS.h>

@interface ViewController ()
    {
        PTFWInitialSetupViewController *paytabsVC;
    }
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

    
    
    - (IBAction)payment:(id)sender {
        NSBundle *bundle = [NSBundle bundleWithURL:[[NSBundle mainBundle] URLForResource:@"Resources" withExtension:@"bundle"]];
                
        paytabsVC = [[PTFWInitialSetupViewController alloc] initWithNibName:@"PTFWInitialSetupView"
                                                                     bundle:bundle
                                                           andWithViewFrame:self.view.frame
                                                              andWithAmount:10.0
                                                       andWithCustomerTitle:@"PayTabs"
                                                        andWithCurrencyCode:@"USD"
                                                           andWithTaxAmount:0.0
                                                         andWithSDKLanguage:@"en"
                                                     andWithShippingAddress:@"عُنوان البَريد الإلِكتْروني"
                                                        andWithShippingCity:@"jeddah عَنوِن / يَكتُب العُنوان™™™ 29393 .. 48493 $"
                                                     andWithShippingCountry:@"BHR"
                                                       andWithShippingState:@"123"
                                                     andWithShippingZIPCode:@"NBsdjbd."
                                                      andWithBillingAddress:@"عُنوان البَريد الإلِكتْروني"
                                                         andWithBillingCity:@"Manama"
                                                      andWithBillingCountry:@"BHR"
                                                        andWithBillingState:@"Manama"
                                                      andWithBillingZIPCode:@"0097"
                                                             andWithOrderID:@"00987"
                                                         andWithPhoneNumber:@"0097335532915"
                                                       andWithCustomerEmail:@"humayun4206@gmail.com"
                                                          andIsTokenization:true
                                                       andWithMerchantEmail:@"humayun@paytabs.com"
                                                   andWithMerchantSecretKey:@"NXKkEpuYSMpvpeYEQzisFh4oUZzCLNIzKsUpSpnLbNhB1ffSPxkvPpTKosmag5K1yEqq3OceBtPDI5vyDQ3sgXcFqzQGEAHcf8Di"
                                                        andWithAssigneeCode:@"SDK"
                                                          andWithThemeColor:[UIColor colorWithRed:225.0/255.0 green:225.0/255.0 blue:225.0/255.0 alpha:1.0]
                                                       andIsThemeColorLight:true];
        __weak typeof(self) weakSelf = self;
        paytabsVC.didReceiveBackButtonCallback = ^{
            [weakSelf closePayTabsView];
        };
        
        paytabsVC.didReceiveFinishTransactionCallback = ^(int responseCode, NSString * _Nonnull result, int transactionID, NSString * _Nonnull tokenizedCustomerEmail, NSString * _Nonnull tokenizedCustomerPassword, NSString * _Nonnull token, BOOL transactionState) {
            
            if (transactionState){
                // true state
            }else {
                // false state
            }
            NSLog(@"%d",responseCode);
            NSLog(@"%@",result);
            NSLog(@"%d",transactionID);
            NSLog(@"%@",tokenizedCustomerEmail);
            NSLog(@"%@",tokenizedCustomerPassword);
            NSLog(@"%@",token);
            [weakSelf closePayTabsView];
            
        };
        
        
        [self.view addSubview:paytabsVC.view];
        [self addChildViewController:paytabsVC];
        [paytabsVC didMoveToParentViewController:self];
    }

    - (void) closePayTabsView {
        [self->paytabsVC willMoveToParentViewController:self];
        [self->paytabsVC.view removeFromSuperview];
        [self->paytabsVC removeFromParentViewController];
    }
    
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
