//
//  PTFWFinishTransactionView.h
//  paytabs-iOS
//
//  Created by PayTabs LLC on 10/25/17.
//  Copyright © 2017 PayTabs LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PTFWFinishTransactionView : UIView<UITextFieldDelegate>

#pragma mark - IBOutlets
@property (weak, nonatomic, nullable) IBOutlet UILabel *navigationBarTitle;
@property (weak, nonatomic, nullable) IBOutlet UILabel *transactionStateLabel;
@property (weak, nonatomic, nullable) IBOutlet UILabel *transactionMessageLabel;
@property (weak, nonatomic, nullable) IBOutlet UILabel *transactionIDLabel;

@property (weak, nonatomic, nullable) IBOutlet UIButton *continueButton;

@property (weak, nonatomic, nullable) IBOutlet UIImageView *successfulTransactionStateIcon;
@property (weak, nonatomic, nullable) IBOutlet UIImageView *unsuccessfulTransactionStateIcon;
@property (weak, nonatomic, nullable) IBOutlet UIImageView *mbmeHeaderImageView;

@property (weak, nonatomic, nullable) IBOutlet UIView *navigationBarView;
@property (weak, nonatomic, nullable) IBOutlet UIView *genericSDKFooterView;
@property (weak, nonatomic, nullable) IBOutlet UIView *mbmeSDKFooterView;

@property (weak, nonatomic, nullable) IBOutlet NSLayoutConstraint *navigationBarHeightConstaint;
@property (weak, nonatomic, nullable) IBOutlet NSLayoutConstraint *inputViewHeightConstraint;
@property (weak, nonatomic, nullable) IBOutlet NSLayoutConstraint *footerHeightConstraint;

@property (weak, nonatomic, nullable) IBOutlet NSLayoutConstraint *navigationBarContentTopConstaint;
@property (weak, nonatomic, nullable) IBOutlet NSLayoutConstraint *contentViewTopConstaint;
@property (weak, nonatomic, nullable) IBOutlet NSLayoutConstraint *transactionStateLabelTopConstaint;
@property (weak, nonatomic, nullable) IBOutlet NSLayoutConstraint *continueTopConstaint;
@property (weak, nonatomic, nullable) IBOutlet NSLayoutConstraint *footerContentBottomConstraint;
@property (weak, nonatomic, nullable) IBOutlet NSLayoutConstraint *mbmeFooterContentBottomConstraint;

@property (weak, nonatomic, nullable) IBOutlet NSLayoutConstraint *leadingContentConstraint;
@property (weak, nonatomic, nullable) IBOutlet NSLayoutConstraint *trailingContentConstraint;
@property (weak, nonatomic, nullable) IBOutlet NSLayoutConstraint *leadingBodyConstraint;
@property (weak, nonatomic, nullable) IBOutlet NSLayoutConstraint *trailingBodyConstraint;

#pragma mark - Callbacks
@property (nonatomic, copy, nullable) void(^didPressContinueButtonCallback)(void);

@end

